package hellojava6;

public class Hello6_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
