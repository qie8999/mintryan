package hellojava6;

public class Hello6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("2 + 5 =" + 2 + 5); //문자열로 변함
		System.out.println("2 + 5 =" + (2 + 5));
		

	}

}
