package hellojava5;

public class Hello5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("|------------------|");
		System.out.println("|�̸�|  ȫ�浿        |");
		System.out.println("|------------------|");
		System.out.println("|����|  100��        |");
		System.out.println("|------------------|");
		System.out.println("|�ּ�| ���� �Ѿ� ȫ�밨��|");
		System.out.println("|------------------|");
		
		
		
	

	}

}
