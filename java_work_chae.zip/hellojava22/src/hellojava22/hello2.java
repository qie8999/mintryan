package hellojava22;

public class hello2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        System.out.println("ä����");
        System.out.println("3_");
        System.out.println("�뱸�� �ϱ�");

	}

}
