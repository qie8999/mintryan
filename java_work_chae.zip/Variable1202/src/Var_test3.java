
public class Var_test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int engJa = 0;
		engJa = 21;
		int engMo = 0;
		engMo = 5;
		
		int hanJa = 0;
		hanJa = 19;
		int hanmo = 0;
		hanmo = 21;
		
		System.out.println(engJa);
		System.out.println(engMo);
		System.out.println(hanJa);
		System.out.println(hanmo);
		
		
				
 
	}

}
