
public class Var5 {

	public static void main(String[] args) {
		String line = "$$$$$$$$$$$$$$$$$$$$$";
		String tatle = "    학생 정보        ";
		String name = "이몽룡";
		String birth ="1600/10/10";
		char nam = '남';
		String hobby = "팽이";
		String strong = "청국어";
		int mom = 100;
		float ki = 1.9f;
		
		System.out.println(line);
		System.out.println(tatle);
		System.out.println(line);
		System.out.println("- 이름    : " + name);
		System.out.println("- 생년월일 : " + birth);
		System.out.println("- 성별   : " + nam);
		System.out.println("- 취미   : " + hobby);
		System.out.println("- 특장점  : " + strong);
		System.out.println("- 몸무게  : " + mom + "kg");
		System.out.println("- 키    :  " + ki +"cm");
		System.out.println(line);

	}

}
