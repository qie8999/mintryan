
public class Val_test {

	
	public static void main(String[] args) {
			}
		
		
	    int obguk = 0;
		obguk = 90;
		
		int obyeong = 0;
		obyeong = 80;
		
		int obsu = 0;
		obsu = 70;
		
		int obgua = 0;
		obgua = 60;
		
		System.out.println(obguk + obyeong + obsu + obgua);
		System.out.println((obguk + obyeong + obsu + obgua) / 4);
		
		
		
		
		
				

	}

}
