
public class Var2 {

	public static void main(String[] args) {
		//문자 변수(첫글자 소문자. class가 아님)
		//ch는 변수명
	
		char ch = '홍';      
		ch = 'A';
		
		//숫자(정수) 타입
		int num = 100;
		
		//숫자(실수)
		float num2 = 10.1f;
		double num3 =10.1;
		
		
		
		

	}

}
