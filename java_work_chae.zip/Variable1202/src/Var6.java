
public class Var6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String line ="------------------------";
		String title ="       개인 신상 정보    "		;
		String name ="홍길동";
		int age =100;
		char nam = '남';
		float mom =60.5f;
		float ki =178.6f;
		String adress ="조선 한양 홍대감댁";
				
		
		System.out.println(line);
		System.out.println(title);
		System.out.println(line);
		System.out.println(" 1. 이름   : " + name);
		System.out.println(" 2. 나이   : " + age + "세");
		System.out.println(" 3. 성별   : " + nam);
		System.out.println(" 4. 몸무게 : " + mom + "kg");
		System.out.println(" 5. 키    : " + ki +"cm");
		System.out.println(" 6. 주소  : " + adress);
		System.out.println(line);
	}

}
