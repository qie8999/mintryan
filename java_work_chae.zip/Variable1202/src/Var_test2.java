
public class Var_test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int huasitem = 40;
		float seopsitem = (huasitem -32) /1.8f;
		
		System.out.println(seopsitem + "��");
		
		

	}

}
