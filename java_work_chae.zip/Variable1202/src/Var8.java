

public class Var8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte b =127;
		int i =100;
		
		
		//타입 변환(형변환, 타입 캐스팅)
		//b가 자동으로 int 타입으로 변환 (숫자로 인식)
		System.out.println(b + i);
		
		
		int num1 = 10;
		int num2 = 4;
		System.out.println(num1 / num2);
		//10과 4 모두 정수이기 때문에 소숫점 아래는 절사 +-*/ 사칙연산자
		
		System.out.println(10.0 / 4);
		//4가 자동으로 4.0으로 변환
		
		System.out.println((char)65);//65를 캐릭터로 강제로 바꿈(아스키코드 문자로)
		//정수 > 문자열 or 정수 > 실수로 바꿔주는 것은 있다
		

		
		
		
		
		
	}

}
