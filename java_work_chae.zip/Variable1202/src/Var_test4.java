
public class Var_test4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		float PI = 3.14f; //PI는 상수. 대문자로만 작성 (상수는 변환이 불가능하다)
		float banjirum = 10f;
		
		System.out.println(banjirum * banjirum * PI);

	}

}
