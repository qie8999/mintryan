import java.util.Scanner;
     
public class Var_test5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("중간고사 점수");
			
				
		String sub;
		int jeomsu = scan.nextInt();
		System.out.println("국어" +  jeomsu );
		
	
	
	
				
	

		
	}}