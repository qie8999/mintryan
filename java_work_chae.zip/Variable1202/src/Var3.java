
public class Var3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	String line = "------------------------";
	String tatle ="       개인 신상 정보       ";
	String name = "홍길동";
	int num = 100;
	char male = '남';
	float mom = 60.5f;
	float ki = 178.6f;
	String adr = "조선 한양 홍대감댁";
	
	System.out.println(line);
	System.out.println(tatle);
	System.out.println(line);
	System.out.println("1. 이름  : " + name);
	System.out.println("2. 나이  : " + num);
	System.out.println("3. 성별  : " + male);
	System.out.println("4. 몸무게 : " + mom + "kg");
	System.out.println("5. 키   : " + ki + "cm");
	System.out.println("6. 주소  : " + adr);
	System.out.println(line);

	}

}
