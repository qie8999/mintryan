
public class Var4 {

	public static void main(String[] args) {
		
	        String line = "**************************";
			String tatle = "      개인 신상 정보     ";
			String name = "황진이";
			int num1 = 18;
			char yeo ='여';
			float mom = 50f;
			float ki = 165f;
			String ard = "조선 한양 한양루 1동";
					
					
					System.out.println(line);
					System.out.println(tatle);
					System.out.println(line);
					System.out.println("1. 이름  : " + name);
					System.out.println("2. 나이  : " + num1);
					System.out.println("3. 성별  : " + yeo);
					System.out.println("4. 몸무게 : " + mom + "kg");
					System.out.println("5. 키   : " + ki + "cm");
					System.out.println("6. 주소  : " + ard);
					System.out.println(line);
 
	}

}
